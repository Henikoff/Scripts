#!/usr/bin/perl
#
#	mult_col.pl <file> <col1> <col2>
#	Mulitples column <col1>*<col2> of <file> and appends
#---------------------------------------------------------------------

if ($#ARGV < 1)
{
   print STDERR "USAGE: mult_two_cols.pl <file> <num> <col>\n";
   print STDERR "Mulitplies column <col1>*<col2> of <file>\n";
   exit(-1);
}

if (!(-s $ARGV[0]))
{
   print STDERR "ERROR: $ARGV[0] does not exist\n";
   exit(-1);
}
if (!(isnumeric($ARGV[1])))
{
   print STDERR "ERROR: $ARGV[1] is not numeric\n";
   exit(-1);
}
if (!(isnumeric($ARGV[2])))
{
   print STDERR "ERROR: $ARGV[2] is not numeric\n";
   exit(-1);
}
$col1 = $ARGV[1];
$col2 = $ARGV[2];
$fcol1 = $col1 - 1;
$fcol2 = $col2 - 1;


open(IN, "$ARGV[0]");
$nin = 0;
while ($in_rec = <IN>)
{
	$nin++;
        @fields = split(/\t|\r|\n/, $in_rec);
#print STDERR "$fields[$fcol]\n";
        if (isnumeric($fields[$fcol1]) && isnumeric($fields[$fcol2])) 
	{
            $x = $fields[$fcol1] * $fields[$fcol2];
            $product = &round($x);
	}
	chop($in_rec);
	print "$in_rec\t$product\n";
} # end of in_rec
close(IN);
exit(0);
#=========================================================================
#   Round a number to three decimal places
sub round
{
  local($x) = @_;
  local($xround);

  $xround = 1000 * $x;
  if ($x >= 0.0)
  {  $xround = int($xround + 0.5);  }
  else
  {  $xround = int($xround - 0.5);  }
  $xround /= 1000;

  return($xround);
} # end of round
#======================================================================
sub isnumeric 
{
    local($x) = @_;
    local($numflag);

    if ($x !~/^[0-9|.|,|-]*$/) 
    { $numflag = 0; }
    else 
    { $numflag = 1; }

    #Check for 9.9e-99, etc.
    if ($numflag==0 && $x =~ m/(\d+)e-(\d+)/)
    { $numflag = 1; }

    return($numflag);
}  #end of isnumeric
